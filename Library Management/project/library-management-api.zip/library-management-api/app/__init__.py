"""Application package initializer."""
